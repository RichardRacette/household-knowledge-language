# Fictional HKL public evidence packet

Every household, source file and review decision in this packet is fictional.
Sources are authored UTF-8 descriptions, not actual photographs or historical documents.
This public view omits restricted source bytes and every derivative depending on them.
There is no fallback source location. policy.json carries permitted evidence-existence
stubs only. Evidence omission does not retract independently Public Demo object metadata;
record privacy must be Restricted to withhold that record's identity. An independently
public source can still describe the same object. Unreachable profile entities are removed.

Run `python -I -S read_packet.py . --isolated` from this directory. No installation,
network, original repository or account is required. The standalone reader checks the
enumerated HKL packet 1.0 subset: complete file inventory and hashes, safe paths,
supported versions, qualified/local references, acyclic derivations, simulated decision
actions/times/links and the retained earlier snapshot, RO-Crate 1.2 root/descriptor
fields, local graph links, curation inputs and software receipt/version consistency.
The three baseline record snapshots are required while their record remains public;
an omitted record's baseline snapshot must also be absent. Fixture-origin receipts agree.
It does not run JSON-LD expansion, full JSON Schema validation, ontology reasoning,
signature authentication, or full RO-Crate compliance testing.

Preservation objectives: recover source bytes; follow source/derivation/decision
links; interpret recorded uncertainty without hidden context. Hashes detect changes
against this manifest, not an attacker who replaces both files and manifest.

corpus.json contains public records; profile.json connects assertions to typed subjects,
source references and decisions. IDs before `/` qualify the record; local IDs must not
be merged. Known is a recorded state, not a proof of truth. Reported remains attributed;
Unknown records a gap. A precisely copied quotation can still be Reported. Simulated
acceptance permits a demonstration plan; it authenticates nobody and approves no family
record. Numeric confidence, repetition and timestamps do not upgrade authority.

Intervals retain expression and precision. Start is inclusive and end exclusive except
an exact date, whose equal bounds indicate a point. Year bounds are search bounds only.
Approximate bounds give possibilities, not probabilities. Open/by bounds do not invent
missing dates. recorded_at dates an assertion; supersedes changes an assertion view,
not the physical event. Earlier assertions and the earlier simulated decision snapshot
remain in history/. Original record snapshots there are explicitly public projections:
their bytes are not claimed to be the original unfiltered repository files.

Reader exercise: inspect the quotation assertion, find its qualified source file, identify
its speaker and epistemic state, and follow its simulated decision. The automated reader
demonstrates these lookups. No human reader study or preservation certification occurred.
LICENSE retains the repository's MIT license. software.json identifies producing code.
